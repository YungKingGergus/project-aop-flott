
public class ServiceApp {
   private String name;

   public ServiceApp(String name) {
      this.name = name;
   }

   public String getName() {
      return name;
   }
}
